{\rtf1\ansi\ansicpg1252\cocoartf1038\cocoasubrtf290
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\paperw11900\paperh16840\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\ql\qnatural\pardirnatural

\f0\fs24 \cf0 Este diret\'f3rio cont\'e9m todos os scripts S+ e MATLAB utilizados na tese de doutoramento de Alexandre Barbosa de Lima intitulada "Contribui\'e7\'f5es \'e0 Modelagem de Teletr\'e1fego Fractal" (defendida na EPUSP em 28/02/2008).}